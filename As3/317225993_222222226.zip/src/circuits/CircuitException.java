package circuits;

public class CircuitException extends Exception{
	public CircuitException(String msg) {
		super(msg);
	}
}
