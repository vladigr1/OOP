package mines;

public interface StrategySquare {
	public void handle(int i,int j);
}
